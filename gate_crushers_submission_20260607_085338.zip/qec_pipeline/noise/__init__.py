"""Noise-model modules."""
